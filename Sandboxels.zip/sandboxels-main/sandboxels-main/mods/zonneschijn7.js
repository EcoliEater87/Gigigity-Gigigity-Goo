elements.green_wall = {
	color: "#00ff00",
	behavior: behaviors.WALL,
	category: "land",
	state: "solid",
};