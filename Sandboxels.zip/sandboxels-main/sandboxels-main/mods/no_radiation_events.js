window.addEventListener("load",function(){
randomEventChoices.falling_pixel.splice(randomEventChoices.falling_pixel.indexOf("fallout"),1);randomEventChoices.explosion.splice(randomEventChoices.explosion.indexOf("radiation"),1)
})
